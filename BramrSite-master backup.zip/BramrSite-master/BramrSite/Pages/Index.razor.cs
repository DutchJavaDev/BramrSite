﻿using Microsoft.AspNetCore.Components;

namespace BramrSite.Pages
{
    public partial class Index : ComponentBase
    {
        
    }
}
